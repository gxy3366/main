import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题
plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理


def Predict(temp, model_stype):
    """预测气温"""
    test_data = pd.read_csv(f"./train/{temp}_test.csv")
    train = test_data.drop(temp, axis=1)
    test = test_data[temp]
    model = joblib.load(f'./model/{model_stype}-model_{temp}.pkl')
    pre = model.predict(train)
    # print(type(pre))
    # print(pre)
    # 平均绝对误差(MAE)
    mae = mean_absolute_error(test, pre)
    print(f"{model_stype}-{temp}平均绝对误差：", mae)
    # 均方误差    -->越小越好
    mse = mean_squared_error(test, pre)
    print(f"{model_stype}-{temp}均方误差：", mse)
    # 如果使用线性回归计算R2评估,越接近1代表模型的拟合程度越好
    # 表示模型完全拟合数据，预测值与真实值完全一致；当R²为0时，表示预测值与真实值无关。因此，通常情况下，R²指数越大越好，表示模型的预测能力越强。
    if model_stype == 'LR':
        # R²计算
        r2_sq = r2_score(test, pre)
        print(f"{model_stype}-{temp}--R²指数：", r2_sq)
    RrePlot(pre, test_data, temp, model_stype)


def RrePlot(pre, df, temp, model_stype):
    """数据可视化"""
    df_act = df[temp]
    fig, ax = plt.subplots()
    # 绘制折线图
    ax.plot(df["day"], df_act, label='真实数据')
    ax.plot(df["day"], pre, label='预测数据')
    # 添加图例、坐标轴标签和标题
    ax.legend()
    ax.set_xlabel('日期')
    ax.set_ylabel('温度')
    ax.set_title(f'{model_stype}-{temp}温度预测天气对比')
    # # 显示图形
    # plt.show()
    plt.savefig(f"./img/{model_stype}-{temp}预测天气对比.png", dpi=1000)
    print('-->对比图片已保存')


if __name__ == '__main__':
    # 创建目录
    dir_name = "./img"
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)
    # 循环进行预测,可视化保存
    for i in ['RF', 'LR']:
        for j in ['max', 'min']:
            Predict(j, i)
