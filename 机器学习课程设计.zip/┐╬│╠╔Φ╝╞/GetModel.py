import os
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, RandomizedSearchCV


# print(df_min.shape)
# X	待划分的样本特征集合
# y	待划分的样本标签
# test_size	若在0~1之间，为测试集样本数目与原始样本数目之比；若为整数，则是测试集样本的数目。
# random_state	随机数种子
# X_train	划分出的训练集数据（返回值）
# X_test	划分出的测试集数据（返回值）
# y_train	划分出的训练集标签（返回值）
# y_test	划分出的测试集标签（返回值）


def RFModel(temp):
    """随机森林随即搜索查找最佳参数及创建最佳模型"""
    print("正在训练随机森林模型。。。")
    # 随机树森林模型 n_estimators决策树数量
    # random_statebootstrap的随机性以及选取样本的随机性
    data = pd.read_csv(f"./train/{temp}_data.csv")
    # 待划分的样本特征集合
    X = data.drop(temp, axis=1)
    # 待划分的样本标签
    y = data[temp]
    # 将指定训练数据集随机分布,效果更好
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1, random_state=10)
    #   模型调优
    print("模型调优")
    # 给定参数搜索范围
    n_estimators = [int(x) for x in np.linspace(start=200, stop=2000, num=10)]
    max_depth = [int(x) for x in np.linspace(10, 20, num=2)]
    max_depth.append(None)
    min_samples_split = [2, 5, 10]
    min_samples_leaf = [1, 2, 4]
    bootstrap = [True, False]
    random_grid = {'n_estimators': n_estimators,
                   'max_depth': max_depth,
                   'min_samples_split': min_samples_split,
                   'min_samples_leaf': min_samples_leaf,
                   'bootstrap': bootstrap}
    # 创建随机森林模型
    rf = RandomForestRegressor()
    # 用RandomSearch+CV选取超参数
    rf_random = RandomizedSearchCV(estimator=rf, param_distributions=random_grid,
                                   n_iter=100, scoring='neg_mean_absolute_error',
                                   cv=3, verbose=2, random_state=42, n_jobs=-1)
    # 训练模型
    rf_random.fit(X_train, y_train)
    print("最佳参数：")
    print(rf_random.best_params_)

    # 保存模型
    joblib.dump(rf_random.best_estimator_, f"./model/RF-model_{temp}.pkl")
    print("模型保存")


def LRModel(temp):
    """线性回归模型训练"""
    # 读取数据
    data = pd.read_csv(f'./train/{temp}_data.csv')
    # 待划分的样本特征集合
    X = data.drop(temp, axis=1)
    # 待划分的样本标签
    y = data[temp]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=1, random_state=10)
    # 创建并训练模型
    reg = LinearRegression().fit(X_train, y_train)
    # 保存模型
    joblib.dump(reg, f"./model/LR-model_{temp}.pkl")
    print("线性回归模型保存")


if __name__ == '__main__':
    dir_name = "./model"
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)
    # 分别训练最高气温和最低气温的模型
    temps = ['max', 'min']
    for e in temps:
        # RFModel(e)
        LRModel(e)
