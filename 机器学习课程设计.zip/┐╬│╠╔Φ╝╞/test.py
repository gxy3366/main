from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题
plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理


def o(temp='max'):
    #    # 读取数据
    #    data = pd.read_csv('./train/max_data.csv')
    #    # 去除包含缺失值的行
    #    # data.dropna(inplace=True)
    #
    #    # 提取特征和标签
    #    X = data[['day','last', 'before']]
    #    y = data['max']
    #
    #    # 创建并训练模型
    #    reg = LinearRegression().fit(X, y)
    #
    #    # 预测今年五月份最高气温
    #    test = pd.read_csv('./train/max_test.csv')
    #    last_mbefore = test[['day','last', 'before']]   # 去年五月份最高气温
    # # 前年五月份最高气温
    #
    #    predict_max_temp = reg.predict(last_mbefore)
    #    errors = abs(predict_max_temp - test['max'])
    #    mape = np.mean(100 * (errors /test['max']))
    #    accu = 100 - mape
    #    print("准确度：", round(accu, 2), "%")
    #    print('预测的最高气温为：')
    #    print(predict_max_temp)

    # 读取数据
    data = pd.read_csv('./train/max_data.csv')

    # 根据年、月、日提取出日期序列，这里假定日期格式为'XXXX-XX-XX'
    data['date'] = pd.to_datetime(
        data['year'].astype(str) + '-' + data['month'].astype(str) + '-' + data['day'].astype(str))
    data.set_index('date', inplace=True)
    # 提取特征和标签
    X = data[['day', 'last', 'before']]
    y = data['max']

    # 创建并训练模型
    reg = LinearRegression().fit(X, y)

    # 预测今年五月份每日最高气温
    test_data = pd.read_csv('./train/max_test.csv')
    predict_X = test_data[['day', 'last', 'before']]
    pre = reg.predict(predict_X)
    test = test_data['max']
    print('预测的最高气温为：')
    print(pre)
    errors = abs(pre - test)
    mape = np.mean(100 * (errors / test))
    accu = 100 - mape
    print("准确度：", round(accu, 2), "%")
    RocPlot(pre, test_data, 'max')

def RocPlot(pre, df, temp):
    df_act = df[temp]
    fig, ax = plt.subplots()
    # 绘制折线图
    ax.plot(df["day"], df_act, label='y1')
    ax.plot(df["day"], pre, label='y2')
    # 添加图例、坐标轴标签和标题
    ax.legend()
    ax.set_xlabel('日期')
    ax.set_ylabel('温度')
    ax.set_title(f'{temp}温度预测天气对比')
    # # 显示图形
    # plt.show()
    plt.savefig(f"./img/line{temp}预测天气对比.png", dpi=1000)


if __name__ == '__main__':
    o()
