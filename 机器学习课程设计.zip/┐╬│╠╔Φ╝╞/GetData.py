import csv
import sys
from fake_useragent import UserAgent
import requests
import os
from lxml import html
import openpyxl

# lxml使用解析源码方法
etree = html.etree
# 请求头
header = {
    "Referer": "http://lishi.tianqi.com/",
    "Host": "lishi.tianqi.com",
    "user-agent": UserAgent().random

}


# 拼接url到一个列表
def GetLink():
    links = []
    for i in range(12, 24):
        # 爬取到南阳2011到2023五月的范围内气温数据
        num = '20' + str(i).zfill(2) + "05"
        link = f'https://lishi.tianqi.com/nanyang/{num}.html'
        # print(url)
        links.append(link)
    return links


# 获取目标网站服务器响应
def GetResponse(link):
    response = requests.get(link, headers=header)
    print(response)
    # 判定响应代码
    if response.status_code == 200:
        cont = response.content.decode()
        return cont
    else:
        sys.exit()


# lxml解析源代码，选择选中数据
def SelectData(content, ws):
    # 解析服务器响应的文件
    parse_html = etree.HTML(content)
    # 提取列表元素标签
    lis = parse_html.xpath('//*[@class="thrui"]/li')
    for li in lis:
        # 返回列表格式，取出数据
        date = li.xpath("./div[1]/text()")[0]
        max_tem = li.xpath("./div[2]/text()")[0]
        min_tem = li.xpath("./div[3]/text()")[0]
        weather = li.xpath("./div[4]/text()")[0]
        windy = li.xpath("./div[5]/text()")[0]
        # print(date, max_tem, min_tem, windy)
        datalist = [date, max_tem, min_tem, weather, windy]
        # 拼接按行写入
        ws.append(datalist)
        # print(datalist)


def MakeDir(dir_name):
    """创建保存数据目录"""
    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)


if __name__ == '__main__':
    dir_path = "train"
    MakeDir(dir_path)
    file_path = "train/天气数据.xlsx"
    wb = openpyxl.Workbook()
    ws = wb.active
    # 获取列名:日期 最高气温 最低气温 天气风向
    col_title = ["日期", "最高气温", "最低气温", "天气", "风向"]
    ws.append(col_title)
    # 获取拼接url连接
    urls = GetLink()
    for url in urls:
        print("正在爬取" + url[-11:-7] + "年" + url[-7:-5] + "月数据。。。")
        content = GetResponse(url)
        SelectData(content, ws)
    print("正在保存。。。")
    wb.save(file_path)
    wb.close()
