import os
import pandas as pd
import numpy as np


def DataClean():
    """数据预处理提供训练数据处理"""
    # 往年数据处理
    data = pd.read_excel("./train/天气数据.xlsx")
    # print(data.head())
    # print(data.columns)
    # 第一列日期数据切片
    data['date'] = data['日期'].map(lambda x: x.split(" ")[0])
    data['week'] = data['日期'].map(lambda x: x.split(" ")[1])
    data['max'] = data['最高气温'].map(lambda x: x.replace('℃', '')).astype("int64")
    data['min'] = data['最低气温'].map(lambda x: x.replace('℃', '')).astype("int64")
    data['date'] = pd.to_datetime(data['date'])
    data['year'] = data['date'].dt.year
    data['month'] = data['date'].dt.month
    data['day'] = data['date'].dt.day
    data = data[['year', 'month', 'day', 'max', 'min']]
    # print(data)
    # 数据文本特征独热编码处理----->哑特征处理
    # data = pd.get_dummies(data)
    # print(data)
    for value, group in data.groupby('year'):
        dir_name = "./train/years/"
        if not os.path.isdir(dir_name):
            os.makedirs(dir_name)
        filename = dir_name + str(value) + '.' + 'csv'
        # print(group.head())
        try:
            f = open(filename, 'w')
            if f:
                # 清空文件
                f.truncate()
                # 写入新文件
                group.to_csv(filename, sep=',', index=False, mode='w', encoding='utf-8')
        except Exception as e:
            print(e)


def DataOuter(temp):
    """数据集按最高气温最低气温处理输出"""
    path = f"./train/years/"
    dir_name = f'./train/{temp}/'
    files = os.listdir(path)

    if not os.path.isdir(dir_name):
        os.makedirs(dir_name)
    # 遍历文件夹下的所有csv文件
    for index, file in enumerate(files):
        # 前两年数据不处理，后面以前两年气温分别化为last，before数据列，作为模型特征
        if file.endswith('.csv'):
            if index < 2:
                continue
            # print(type(file))
            num = int(file[0:4])
            # print(num)
            li = ['max', 'min']
            # print(temp)
            d = li[1] if temp == li[0] else li[0]
            # print(d)
            # 删除最高或最低气温干扰项
            data = pd.read_csv(path + file)
            data = data.drop(d,axis=1)
            # 读取本年的前年和去年数据，作为last、before
            last_file = path + f'{num - 1}.csv'
            before_file = path + f'{num - 2}.csv'
            data['last'] = pd.read_csv(last_file)[temp]
            data['before'] = pd.read_csv(before_file)[temp]
            # 去除年份
            # data = data.drop("year", axis=1)
            # 将2023年数据提出写为测试集
            if num == 2023:
                data.to_csv(f"./train/{temp}_test.csv", sep=',', encoding='utf-8', index=False)
                data.to_csv(dir_name + file, sep=',', encoding='utf-8', index=False)
            else:
                data.to_csv(dir_name + file, sep=',', encoding='utf-8', index=False)
    DataSum(temp)


def DataSum(temp):
    """数据集拼接"""
    dir_name = f'./train/{temp}/'
    files = os.listdir(dir_name)
    df = pd.DataFrame()
    # 遍历文件夹下的所有csv文件
    # 分别拼接2014-2022年5月最高气温最低气温为一个数据集,
    for index, file in enumerate(files):
        if index == 0:
            continue
        if file.endswith('.csv'):
            data = pd.read_csv(dir_name + file)
            df = pd.concat([df, data])
    df.to_csv(f"./train/{temp}_data.csv", sep=',', encoding='utf-8', index=False)


if __name__ == '__main__':
    # 数据清洗
    DataClean()
    # 数据输出
    for i in ['min', 'max']:
        DataOuter(i)
