data<-read.csv("豆瓣排行榜.csv", encoding = "UTF-8")
data <- na.omit(data)#删除有空值的行
rownames(data)<- 1:nrow(data)#重置索引
#dataframe $代表某列
mat1<-data.frame(names<-data$电影名字,value=data$评价人数)
mat2<-data.frame(names<-data$电影名字,value=data$评分)
mat3<-data.frame(names<-data$电影名字,value=data$上映年份)
installed.packages("wordcloud2")
installed.packages("webshot")
library(wordcloud2) #加载包
library(webshot)
webshot::install_phantomjs() #首次使用需要执行
installed.packages("htmlwidgets")
library(htmlwidgets)
# 0.词云图设定 | 根据评分人数设置
plot0<- wordcloud2(mat1,
           size = 0.1,shape = "pentagon",backgroundColor = "grey",
           minRotation = 30,maxRotation = 45,rotateRatio = 0.3,
           color = "random-light") + WCtheme(1)
saveWidget(plot0,"tmp.html",selfcontained = F) #先保存为网页格式
webshot("tmp.html","wordcloud.jpg", delay = 3,vwidth = 1000, vheight=1000) #在依据网页格式生成jpg图片格式
#其中“delay =”设置在保存图片之前需要等待的时间(单位：秒)，这主要是因为字云图要完全显示出绘制的单词时间较慢，需要等到，需要依据显示的单词数量合理设置；
#“vwidth =”和“ vheight=”指定保存时的高宽
# 数据统计分组
# 1.评分统计图
table1 <- table(mat2$value)#频数表
# 8.3 8.4 8.5 8.6 8.7 8.8 8.9   9 9.1 9.2 9.3 9.4 9.5 9.6 9.7 
# 3   9  30  72 120 123 111  48  87  42  63  18  12   9   3 
p1<-data.frame(table1)
library(ggplot2)
library(ggthemes)#图表主题样式包
plot1<-ggplot(data=p1,mapping=aes(x=Var1,y=Freq,fill=Var1,group=factor(1)))+
      geom_bar(stat="identity",width=0.8,position = 'stack') +   #基础图表
    theme_bw()+
    labs(x="评分",y="数量",fill="图例",title="豆瓣电影评分数据概述")+
    theme(
    #标题字体设置
    text=element_text(size=12),
    #设置标题居中hjust = 0.5
    plot.title = element_text(hjust = 0.5,vjust = 0), 
    #Y轴字体设置
    axis.text.y=element_text(size=12,color = "black"),
    #X轴字体设置
    #angle：调整横轴标签倾斜角度
    #hjust：上下移动横轴标签
    axis.text.x=element_text(size=12,  color = "black",angle = 45, hjust = 0.5,
                             vjust = 0.5),
    #图例的标题字体设置，可以修改colour、size
    legend.title=element_text(size=15))+ labs(x="评分",y="数量",title="电影评分分析")
plot1
ggsave("plot1.png", plot = plot1,
       scale = 1, 
       dpi = 1000)

# 2.时间折线图
table2<-table(mat3$value)
table2
p2<-data.frame(table2)
p2<-p2[-11,]
rownames(p2)<- 1:nrow(p2)
library(ggplot2)
plot2<- ggplot(data = p2 , mapping = aes(x = Var1, y = Freq)) + 
    geom_point()+geom_line(size=0.5)+geom_line(data=p2,aes(x=Var1, y=Freq),
                                             group = 1,size=0.5,linetype="solid",
                                             colour="red")+
    theme( #标题字体设置
      text=element_text(size=12),
      #设置标题居中hjust = 0.5
      plot.title = element_text(hjust = 0.5,vjust = 0), 
      #Y轴字体设置
      axis.text.y=element_text(size=12,color = "black"),
      #X轴字体设置
      #angle：调整横轴标签倾斜角度
      #hjust：上下移动横轴标签
      axis.text.x=element_text(size=5,  color = "black",
                               angle = 90, hjust = 0.5,vjust = 0.5))+
      labs(x="上映年份",y="数量",title="电影上映年份分析")+
  legend.title=element_text(size=15))
plot2
ggsave("plot2.png", plot = plot2,
       scale = 1, 
       dpi = 1000)
# 3.饼图  |根据评分数据划分图形
summary(mat2$value)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 8.300   8.700   8.900   8.912   9.100   9.700 
group1<-cut(mat2$value,c(seq(8,10,1)),include.lowest = TRUE)
group1<-data.frame(group1)#分组统计
group1
percentage <- scales::percent(p1$Freq / sum(p1$Freq)) #计算百分比，利用scales包的percent()函数，将计算的小数比例转换成百分数
percentage
library(ggplot2)

label_value <- paste('(', round(p1$Freq/sum(p1$Freq) * 100, 1), '%)', sep = '')
label_value#将百分比表示出来
label <- paste(p1$Var1, label_value, sep = '')
label#下面还需要为这些百分比值对应到各个组。
plot3<-ggplot(data=p1,mapping=aes(x='Var',y=Freq,fill=Var1))+
  geom_bar(stat="identity",width=1,position = 'stack')+coord_polar(theta='y')+
  labs(x = '', y = '', title = '豆瓣评分统计')+theme(axis.text = element_blank(),
                    plot.title = element_text(hjust = 0.5,vjust = 0.5),)+
  scale_fill_discrete(labels = label)+theme_bw()
plot3
ggsave("plot3.png", plot = plot3,
       scale = 1, 
       dpi = 1000)


