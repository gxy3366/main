a = list.files("天气数据")                                                       #list.files命令将input文件夹下所有文件名输入ass
dir = paste("./天气数据/",a,sep="")#用paste命令构建路径变量dir
n = length(dir)                                                                 #读取dir长度，也就是文件夹下的文件个�?
merge.data = read.csv(file = dir[1],header=T,sep=",", encoding = "UTF-8")   #读入第一个文件内容（可以不用先读一个，但是为了简单，省去定义data.frame的时间，我选择先读入一个文件�?
for (i in 2:n){
  new.data = read.csv(file = dir[i], header=T, sep=",",encoding = "UTF-8")
  merge.data = rbind(merge.data,new.data)
}
write.csv(merge.data,file = "./天气数据/merge.csv",row.names=F)
rownames(merge.data)<- 1:nrow(merge.data)#重置索引
merge.data$日期<- as.Date(merge.data$日期,format="%Y年%m月%d日") #转成日期
library(lubridate)
merge.data$year<- format(merge.data$日期,"%Y")
merge.data$day<-format(merge.data$日期,"%d")#提取日为DAY
library (stringr)
merge.data$temp<-gsub('[℃]', '', merge.data$气温)#删去温度符号
merge.data$temp<-gsub('[/]','', merge.data$temp)#删去/
temp1<-str_split_fixed(merge.data$temp, ",",3)#拆分最高低温度


merge.data$high_temp<-temp1[,1]#分别对应入座
merge.data$low_temp<-temp1[,3]
merge.data$high_temp<-as.numeric(as.character(merge.data$high_temp))#转成向量，再转成数字
merge.data$low_temp<-as.numeric(as.character(merge.data$low_temp))

merge.data<- merge.data[,-7]#删除18,/,16这种列
n_data<-merge.data
n_data1<-merge.data[,c(2,5,6,7)]
n_data2<-merge.data[,c(2,5,6,8)]
#1.气温分析
library(ggplot2)
library(dplyr)
n1<-group_by(n_data1,year) 
n2<-group_by(n_data2,year) 
n1$high_temp <- as.numeric(as.character(n1$high_temp))
n2$low_temp <- as.numeric(as.character(n2$low_temp))
photo1 <- ggplot(data = n1,mapping = aes(x = day, y = high_temp,
                                     group=year ,fill=high_temp),colour=year ) +
      geom_point()+geom_path()+ 
      geom_smooth(method = "loess",formula = y ~ I(x))+
      geom_line(data = n1, mapping = aes(x = day, y = high_temp,colour=year),
                size=0.5)+ theme_bw()+
    labs(x="日期",fill="图例",y="温度/℃",title="近年新乡11月最高气温分析")+
  theme(plot.title = element_text(hjust = 0.5,vjust = 0))

photo2 <- ggplot(data = n2,mapping = aes(x = day, y = low_temp,
                                     group=year ,fill=low_temp),colour=year ) +
    geom_point()+geom_path()+ 
    geom_smooth(method = "loess",formula = y ~ I(x))+
    geom_line(data = n2, mapping = aes(x = day, y = low_temp,colour=year),
              size=0.5)+ theme_bw()+
    labs(x="日期",fill="图例",y="温度/℃",title="近年新乡11月最低气温分析")+
    theme(plot.title = element_text(hjust = 0.5,vjust = 0))

ggsave("新乡最高气温分析.png", plot = photo1,scale = 3,dpi = 1000)
ggsave("新乡最低气温分析.png", plot = photo2,scale = 3,dpi = 1000)
#2.预测尝试
n_data[,c(1:4)] <- as.numeric(unlist(n_data[,c(1:4)]))
dev.new()
png(file="新乡2011-2021最高最低气温时序图.png", bg="transparent",width=1800,height=900,res=72*3)

highestTS <-ts(n_data$high_temp[1:(30*10)],frequency=30,start=c(2011,11,1))
plot(highestTS,col="red",main="新乡2011-2021最高最低气温时序图")
lowestTS <-ts(n_data$low_temp[1:(30*10)],frequency=30,start=c(2011,11,1))
lines(lowestTS,col="blue")
legend("topright",cex=0.5,c("最高气温","最低气温"),col=c("red","blue"),lty=1,text.width=0.5)

dev.off()

library("forecast")
dev.new()
png(file="新乡未来最高最低气温预测时序图.png", bg="transparent",width=1800,height=900,res=72*3)

highestForecasts<- HoltWinters(highestTS)
lowestForecasts<- HoltWinters(lowestTS)

highestForecast2<- forecast(highestForecasts,h=150)
lowestForecast2<- forecast(lowestForecasts,h=150)
plot(highestForecast2$mean,ylim=c(-15,20),col="red",main="新乡未来最高最低气温预测时序图",xlab="时间",ylab="温度℃")
lines(lowestForecast2$mean,col="blue")
legend("topright",c("最高气温","最低气温"),col=c("red","blue"),lty=1)
dev.off()

# 3.简单测试预测准确性
Box.test(highestForecast2$residuals,lag=20,type="Ljung-Box")
Box.test(lowestForecast2$residuals,lag=20,type="Ljung-Box")
#X-squared = 43.889, df = 20, p-value = 0.001557可见最高气温预测较为准确
#data:  lowestForecast2$residuals
#X-squared = 72.078, df = 20, p-value = 8.309e-08可见最低气温预测有所差别


