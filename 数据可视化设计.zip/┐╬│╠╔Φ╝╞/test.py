import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm  # 字体库
from matplotlib import cm
import matplotlib.style as ms

dir_name = "./img/"
if not os.path.isdir(dir_name):
    os.makedirs(dir_name)
# 用 replace() 函数将包含 "自治区" 的字符串替换为 省
df['地区'] = df['地区'].replace('.*自治区.*', "省", regex=True)
# 将广西壮族省转换为广西省
df["地区"] = df["地区"].apply(lambda x: x[:2] + "省" if len(x) > 4 else x)
# 设置主题风格
ms.use("ggplot")
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题
plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理

# 读取数据(大陆数据)
df_Gdp = pd.read_excel("./data/data.xlsx", sheet_name="生产总值")
# df_Average = pd.read_excel("./data/data.xlsx", sheet_name="人均生产总值")
# df_industry = pd.read_excel("./data/data.xlsx", sheet_name="工业增长值")
# df_Category = pd.read_excel("./data/data.xlsx", sheet_name="房地产增长值")
# df_Finance = pd.read_excel("./data/data.xlsx", sheet_name="金融业增长值")
# 2022年各省GDP数据饼图设计
# 提取数据
provinces = df_Gdp['地区']
gdp_values = df_Gdp['2022年']
# print(provinces)
# 设置最大值突出显示
explode = [0 if i != max(gdp_values) else 0.1 for i in gdp_values]  # 突出最大值
fig, axes = plt.subplots(figsize=(12, 6), ncols=2)  # 设置绘图区域大小
# 包含两张图
ax1, ax2 = axes.ravel()
# 绘制全国各省占比饼图
wedges, texts, dfs = ax1.pie(gdp_values, explode=explode, labels=provinces, autopct='%1.1f%%', startangle=90,
                             labeldistance=1.1, pctdistance=1.1)
# 修改标签字体样式
plt.setp(texts, fontweight='light')
ax1.axis('equal')  # 让饼图看起来更圆
ax1.title.set_text("全国各省生产占比饼图")
# 绘制河南省占比数据饼图
labels = ["河南省", "其他省"]
# 找出河南省数据
num = df_Gdp[df_Gdp["地区"] == "河南省"]["2022年"].values[0]
# 求出其他省GDP总值
others = df_Gdp["2022年"].sum() - num
sizes = [num, others]
explode_h = [0, 0.1]
# 绘制全国各省占比饼图
ax2.pie(x=sizes, explode=explode_h, labels=labels, autopct='%1.1f%%', startangle=90)
ax2.axis('equal')  # 让饼图看起来更圆
ax2.title.set_text("河南省生产占比饼图")

plt.suptitle('2022年分省生产总值占比')
plt.show()
