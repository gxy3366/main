import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.style as ms

plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题


def BarPlot():
    """各地区2022年生产总值数据柱状图"""
    # 设置主题风格,字体风格
    ms.use("ggplot")
    plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题
    # 读取数据(大陆数据)
    df_gdp = pd.read_excel("./data/data.xlsx", sheet_name="生产总值")
    gdp = df_gdp["2022年"]
    provinces = df_gdp["地区"]
    # 设置画布大小
    fig, ax = plt.subplots(figsize=(12, 6))
    # 创建水平堆积柱状图
    ax.barh(provinces, gdp)

    # 添加轴标签和图标题
    ax.set_ylabel('地区', fontweight="bold", color="black")
    ax.set_xlabel('生产总值(亿元)', fontweight="bold", color="black")
    ax.set_title('各地区2022年生产总值数据柱状图', fontweight="bold", color="black", y=1.05)

    # 设置柱子标签的字体大小
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(8)

    # 添加数据标签,设置字体大小
    for i, v in enumerate(gdp):
        ax.text(v + 2, i - 0.3, str(v), fontsize=8)
    # 添加网格线
    ax.grid(axis='x', linestyle='--', alpha=1)
    # 添加垂直参考线及标签
    reference_value = gdp.mean()
    ax.axvline(x=reference_value, linestyle="--", color="Gray")
    # 数据标签保留两位小数
    ax.text(reference_value, ax.get_ylim()[1], '{:.2f}'.format(round(reference_value, 2)), ha='center', va='bottom',
            color='black')
    # 添加垂直参考线的解释标签
    ax.annotate('2022年生产总值平均值', xy=(reference_value, 25), xytext=(reference_value + 5000, ax.get_ylim()[1] - 5),
                fontsize=10, color='black', arrowprops=dict(arrowstyle='fancy', color='gray'))
    plt.savefig("./img/各地区2022年生产总值数据柱状图.png", dpi=1000)
    # 显示图形
    plt.show()


def LinePlot():
    """四省近十年生产总值折线图"""
    # 设置主题风格
    ms.use("seaborn")
    plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题

    df = pd.read_excel("./data/data.xlsx", sheet_name="人均生产总值")
    # 提出河南省、河北省、陕西省、广东省数据
    # 创建布尔索引
    mask = (df['地区'] == '河南省') | (df['地区'] == '河北省') | (df['地区'] == '陕西省') | (df['地区'] == '广东省')
    # print(mask)
    # 筛选数据
    result = df[mask]
    # print(result)
    # 选择除了第一列以外的列，并将它们逆序排列
    reversed_columns = list(result.columns[1:][::-1])
    # 将逆序排列后的 DataFrame 存储在 df 中 重置索引
    df = result[["地区"] + reversed_columns].reset_index(drop=True)
    # 将地区列设置为索引列
    df.set_index('地区', inplace=True)
    # 创建一个子图
    fig, ax = plt.subplots(figsize=(12, 6))
    # 添加网格线
    ax.grid(axis='x', linestyle='--', alpha=1)
    ax.grid(axis='y', linestyle='--', alpha=1)
    # 实线 linestyle = '-' 点划线 linestyle = '-.'短虚线 linestyle = ':'长虚线 linestyle = '--'
    # 圆圈 ‘o’, 五角星‘*’, 三角形 ‘^’ ,菱形‘D’,正方形‘s’
    line_styles = ["-.", "-", ":", "--"]
    mark = ["o", "D", "^", "s"]
    colors = ["#40E0D0", "#87CEEB", "#FFC0CB", "#87CEFA"]
    # 循环处理每个地区，绘制相应的折线图
    for region, index in zip(df.index, range(len(df.columns))):
        # 设置颜色，线段风格，数据标记
        ax.plot(df.columns, df.loc[region, :], label=region,
                linestyle=line_styles[index], marker=mark[index], color=colors[index])
        # 添加数据标签，并防止标签重叠
        for i, val in enumerate(df.loc[region, :]):
            # 'bottom'：垂直方向上底部对齐
            if index % 2:
                y_pos = val + 2000
            else:
                y_pos = val - 4000
            ax.text(i, y_pos, str(val), ha='center', va='bottom', fontsize=8,
                    bbox=dict(facecolor=colors[index], edgecolor='gray', boxstyle='round', alpha=0.3))

    # 设置图形标题和轴标签
    ax.set_title('四省近十年人均生产总值变化折线图', fontweight="bold", y=1.05, fontsize=14)
    ax.set_xlabel('年份', fontweight="bold")
    ax.set_ylabel('人均生产总值(亿元)', fontweight="bold")
    # 在2020年上添加注释文本
    ax.annotate('20年因疫情人均生产总值增长\n受到影响，但依旧平缓增长', xy=(7, 88521), xytext=(5, 100000),
                arrowprops=dict(facecolor='black', arrowstyle='->'),
                bbox=dict(facecolor='white', edgecolor='gray', boxstyle='round'),
                fontsize=10, ha='center', va='top')
    # 添加图例
    ax.legend()
    # 保存图像
    plt.savefig("./img/四省近十年人均生产总值变化折线图.png", dpi=1000)
    # 显示图形
    plt.show()


def PointPlot():
    """河南省近十年生产总值指数增长值散点图"""
    # 设置主题风格
    ms.use("seaborn-white")
    plt.rcParams['axes.unicode_minus'] = False  # 坐标轴负号的处理
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 显示中文标签,处理中文乱码问题
    df = pd.read_excel("./data/data.xlsx", sheet_name="河南省生产总值指数")
    # 使用str.replace()方法将列名中的括号替换为空字符串
    df.columns = df.columns.str.replace(r'\(.*?\)', '', regex=True)
    # 使用loc方法和[::-1]切片方法将行逆序
    df = df.loc[::-1].reset_index(drop=True)
    # print(df)
    # 设置图像大小
    plt.figure(figsize=(10, 6))
    # 指定x轴和y轴数据
    x = range(df.shape[0])
    colors = ['#0072C6', '#44B78B', '#FFA500', '#8A2BE2']
    for i, column in enumerate(df.columns[1:]):
        y = df[column]
        # 绘制散点图，设置点大小、透明度
        plt.scatter(x, y, c=colors[i], label=column, s=abs(y - 100) * 30, alpha=0.8)
        # 找到指标的最值索引
        value = df[column]
        min_idx = np.argmin(value)
        max_idx = np.argmax(value)
        # print(min_idx)
        # 添加生产总值最值注释文本及注释框
        plt.text(x[min_idx] + 0.1, value[min_idx], f'{value[min_idx]}', ha='left', va='center',
                 fontsize=10, color='b')
        plt.text(x[max_idx] + 0.15, value[max_idx], f'{value[max_idx]}', ha='left', va='center',
                 fontsize=10, color='r')
    # 增加网格线
    plt.grid(True)
    # 替换x轴刻度标签
    plt.xticks(x, df['时间'])
    # 添加图例和坐标轴标签
    plt.legend()
    plt.xlabel('时间')
    plt.ylabel('增加值指数(上年=100)')
    plt.title('河南省近十年各指标增加值指数散点图')
    # 保存图像
    plt.savefig("./img/河南省近十年生产总值指数增长值散点图.png", dpi=1000)
    # 显示图形
    plt.show()


if __name__ == '__main__':
    BarPlot()
    LinePlot()
    PointPlot()
