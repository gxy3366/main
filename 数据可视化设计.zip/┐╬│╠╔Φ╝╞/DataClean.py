import pandas as pd
import numpy as np
import os

# 多表合并
dir_path = f"./data/"
files = os.listdir(dir_path)
writer = pd.ExcelWriter(dir_path + "data.xlsx")
for file in files:
    if file.endswith('.csv'):
        file_path = dir_path + file
        # 读取指定行数据，去除前三行数据说明和最后一行数据来源
        df = pd.read_csv(file_path, header=3, skipfooter=1, encoding="gbk", engine='python')
        # header=3 表示将第四行作为列名。通过这样的方法可以保证第四行作为列名，且前三行被去除。
        # engine :pd.read_csv()默认使用C引擎解析文件，但是C引擎不支持skipfooter
        # 参数skipfooter来跳过CSV文件的最后几行数据
        # print(file)
        # 指定工作表名为数据名称,去除索引
        df.to_excel(writer, sheet_name=file[6:-4], index=False)
writer.save()
