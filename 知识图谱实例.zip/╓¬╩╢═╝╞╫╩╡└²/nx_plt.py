import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = [u"SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams.update({'font.size': 1})  # 设置字体大小


# 绘制无向图
def nx_plt():
    # 读取数据
    data = pd.read_csv('word-word-weight.csv')
    # 去空（缺失值其实是标点，停词过滤有问题）
    data = data.dropna()
    print(data.head())
    plt.figure(figsize=(12, 10))
    G = nx.Graph()
    # 筛选添加节点
    nodes = set(data['Word1']) | set(data['Word2'])
    # print(nodes)
    G.add_nodes_from(nodes)
    for s in range(len(data)):
        e = tuple(data.iloc[s])
        G.add_edge(e[0], e[1], weight=e[2])
    #     绘制无向图
    nx.draw(G, with_labels=True, font_size=10, node_size=100, alpha=1)

    plt.show()


if __name__ == '__main__':
    nx_plt()
